## Przelewy24.pl - Payment Service Module for PrestaShop 1.7 ##
- Author: http://www.przelewy24.pl/

## Requirements ##
- PHP 5.6 minimum
- MySQL 5.0 minimum
- Apache 1.3+, Apache 2.x, Nginx
- cURL 7.0.34 minimum
- SOAP
- memory_limit min "128M" 
- upload_max_file_size min "16M"
- TLS 1.2
