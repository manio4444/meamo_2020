# Change Log #

## [Zencard] - 2016-11-10 ##
- Has coupon field.

## [Przelewy24Product] - 2016-10-13 ##
- Init.
- Added descriptions, doc.




