# Zbiór wspólnych bibliotek/klas dla wszystkich wtyczek sklepowych Przelewy24 #
 

### Minimalne wymagania ###

- PHP 5.2+
- SOAP
- cURL
