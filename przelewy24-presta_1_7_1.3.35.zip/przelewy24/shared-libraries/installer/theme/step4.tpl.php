<?php
/**
 * @author Przelewy24
 * @copyright Przelewy24
 * @license https://www.gnu.org/licenses/lgpl-3.0.en.html
 *
 */

?>
<div class="p24-step p24-step-4">
    <p>
        Dodatkowe informacje
    </p>
    <p>
        Proin nibh augue, suscipit a, scelerisque sed, lacinia
        in, mi. Cras vel lorem. Etiam pellentesque aliquet tellus.
        Proin nibh augue, suscipit a, scelerisque sed, lacinia
        in, mi. Cras vel lorem. Etiam pellentesque aliquet tellus.
    </p>
</div>
